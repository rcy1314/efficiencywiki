if (typeof window !== 'undefined') {
  require('./electron-ipc-cat');
}
